# CLAUDE CODE INSTRUCTIONS — Crypto Training Data Formatter

## WHAT YOU'RE DOING
You have 10 zip files containing ~261,000 crypto news articles from CryptoPanic.
Your job: convert ALL of them into MLX LoRA fine-tuning format (JSONL).

## RAW DATA FORMAT
Each zip contains a .txt file. Each line is pipe-delimited:

```
id | timestamp_ms | year | month | ? | date | source | title | body | url | ? | ? | ? | ? | batch_id
```

Example:
```
cp_1522|1640064600000|2021|12||2021-12-20|cryptopanic|Crypto regulation is coming, but Bitcoin traders are still buying the dip|The premium on CME Bitcoin futures dropped to zero, but data shows pro traders are still bullish.|https://cryptopanic.com/news/13721374/...|||||1770705249203
```

Fields we care about:
- Field 1: record ID
- Field 2: timestamp in milliseconds
- Field 6: date (YYYY-MM-DD)
- Field 7: source
- Field 8: title (THE MOST IMPORTANT FIELD)
- Field 9: body/summary
- Field 10: URL

## OUTPUT FORMAT
MLX LoRA expects JSONL with Mistral instruct format:

```json
{"text": "<s>[INST] {prompt} [/INST] {completion} </s>"}
```

## WHAT TO BUILD
Process ALL 10 zip files and generate THREE types of training pairs per article:

### Type 1: Sentiment Analysis
```json
{"text": "<s>[INST] Analyze this crypto news from 2021-12-20: \"Crypto regulation is coming, but Bitcoin traders are still buying the dip\". What is the sentiment and likely market impact? [/INST] Sentiment: slightly_bearish. The headline discusses incoming regulation (bearish catalyst) but notes traders are buying the dip (bullish response). Mixed signal — regulation fears are offset by strong buy-side conviction. Short-term impact: neutral to slightly bearish. If regulation details are moderate, expect recovery. </s>"}
```

### Type 2: Market Context Analysis  
```json
{"text": "<s>[INST] You are a crypto market analyst. On 2021-12-20, this news broke: \"Crypto regulation is coming, but Bitcoin traders are still buying the dip\". The article states: The premium on CME Bitcoin futures dropped to zero, but data shows pro traders are still bullish. What does this tell us about the current market regime and what should a trader do? [/INST] The CME futures premium dropping to zero indicates institutional caution — this is a warning sign. However, pro traders buying the dip shows conviction hasn't broken. The market is in a correction within a bull cycle. A trader should: maintain current positions but tighten stop losses, avoid adding new positions until momentum confirms direction, and watch for BTC dominance shifts that might signal alt rotation. </s>"}
```

### Type 3: Event Classification
```json
{"text": "<s>[INST] Classify this crypto event: \"Crypto regulation is coming, but Bitcoin traders are still buying the dip\" (2021-12-20). Category, severity, and expected duration of impact? [/INST] Category: regulation. Severity: moderate. Expected duration: weeks to months depending on regulatory specifics. This type of headline typically causes 5-15% pullbacks if regulation materializes, but markets have historically adapted to regulatory clarity within 2-4 weeks. </s>"}
```

## SENTIMENT CLASSIFICATION RULES
Use these keyword groups to auto-classify, then generate appropriate completions:

BULLISH: rally, surge, soar, all-time high, ath, breakout, adoption, approve, partnership, launch, institutional, accumulation, upgrade, mainnet, record
BEARISH: crash, plunge, dump, hack, exploit, ban, crackdown, sec charges, lawsuit, fraud, scam, collapse, bankruptcy, liquidat, freeze, halt, suspend
NEUTRAL: report, analysis, update, review, regulation, stablecoin, development, roadmap

## FILTERING RULES
- SKIP lines with titles shorter than 15 characters
- SKIP lines starting with "RT @" that are under 50 chars (social noise)  
- SKIP lines where body is "NULL" or "-" (set body to empty string)
- SKIP lines that don't have at least 10 pipe-delimited fields
- KEEP everything else — even stablecoin news, even minor altcoin news, ALL of it

## OUTPUT FILES
Split the final JSONL into:
- `train.jsonl` — 80% of pairs (shuffled)
- `valid.jsonl` — 10% of pairs (shuffled)
- `test.jsonl` — 10% of pairs (shuffled)

Save to: `data/training/`

## IMPORTANT
- Process ALL 10 zip files, not just one
- Generate ALL THREE pair types for each valid article (3x the data)
- Shuffle before splitting
- Log progress: how many records processed, how many pairs generated
- Handle encoding errors gracefully (skip bad lines)
- The completions should be DETAILED and ANALYTICAL, not just one word
- Vary the prompt phrasing so the model learns to respond to different question styles
- Target: ~750,000+ training pairs from 261,000 articles (3 pairs each)

## AFTER FORMATTING
Once the JSONL files are generated, the next step is fine-tuning:

```bash
python -m mlx_lm.lora \
  --model mlx-community/Mistral-7B-Instruct-v0.3-4bit \
  --data ./data/training \
  --train \
  --batch-size 2 \
  --iters 1000 \
  --learning-rate 2e-5 \
  --lora-layers 16 \
  --save-every 200 \
  --max-seq-length 2048 \
  --grad-checkpoint
```
